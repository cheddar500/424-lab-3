/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned getval_431()
{
    return 3284634056U;
}

unsigned getval_265()
{
    return 650363736U;
}

unsigned getval_230()
{
    return 3347662929U;
}

void setval_118(unsigned *p)
{
    *p = 3281031256U;
}

unsigned addval_306(unsigned x)
{
    return x + 3284633928U;
}

unsigned getval_369()
{
    return 2425444590U;
}

unsigned getval_305()
{
    return 2496104776U;
}

void setval_403(unsigned *p)
{
    *p = 2425394264U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned addval_243(unsigned x)
{
    return x + 2497743176U;
}

void setval_192(unsigned *p)
{
    *p = 3676360329U;
}

unsigned getval_193()
{
    return 3683962505U;
}

unsigned addval_372(unsigned x)
{
    return x + 3676881545U;
}

void setval_496(unsigned *p)
{
    *p = 3380920961U;
}

void setval_303(unsigned *p)
{
    *p = 3677933960U;
}

void setval_299(unsigned *p)
{
    *p = 3683962505U;
}

void setval_442(unsigned *p)
{
    *p = 3285289317U;
}

unsigned getval_311()
{
    return 3767093920U;
}

unsigned addval_462(unsigned x)
{
    return x + 3524841097U;
}

unsigned addval_285(unsigned x)
{
    return x + 398578057U;
}

unsigned addval_388(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_323(unsigned x)
{
    return x + 3224948361U;
}

void setval_415(unsigned *p)
{
    *p = 3223375489U;
}

unsigned getval_449()
{
    return 3232026249U;
}

unsigned getval_297()
{
    return 3674263945U;
}

unsigned addval_409(unsigned x)
{
    return x + 3529559689U;
}

void setval_456(unsigned *p)
{
    *p = 3247493513U;
}

unsigned getval_459()
{
    return 3769190406U;
}

unsigned addval_208(unsigned x)
{
    return x + 3221803401U;
}

unsigned addval_346(unsigned x)
{
    return x + 3771287598U;
}

void setval_387(unsigned *p)
{
    *p = 2464188744U;
}

unsigned addval_238(unsigned x)
{
    return x + 1103348361U;
}

void setval_274(unsigned *p)
{
    *p = 3375415945U;
}

void setval_211(unsigned *p)
{
    *p = 3229143433U;
}

unsigned addval_206(unsigned x)
{
    return x + 2430634304U;
}

unsigned addval_267(unsigned x)
{
    return x + 2430634312U;
}

void setval_216(unsigned *p)
{
    *p = 2495777102U;
}

unsigned addval_380(unsigned x)
{
    return x + 2428668189U;
}

void setval_250(unsigned *p)
{
    *p = 3523789441U;
}

unsigned getval_411()
{
    return 717472395U;
}

unsigned getval_374()
{
    return 3676361096U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
